package com.example.android.medpharm;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Register extends AppCompatActivity {

    Button doctor,patient,pharmacist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        doctor = (Button)findViewById(R.id.doctorButton);
        patient = (Button)findViewById(R.id.patientButton);
        pharmacist = (Button) findViewById(R.id.pharmacistButton);

    }

    public void buttonClicked(View view) {

        int id = view.getId();

        if(id==R.id.doctorButton){

            Intent i1 = new Intent(this,DoctorRegistration.class);
            startActivity(i1);
        }

        if (id==R.id.patientButton){

            Intent i2 = new Intent(this,PatientRegistration.class);
            startActivity(i2);
        }

        if (id==R.id.pharmacistButton){

            Intent i3 = new Intent(this,PharmacistRegistration.class);
            startActivity(i3);
        }
    }
}
